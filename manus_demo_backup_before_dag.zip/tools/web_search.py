"""
Web Search Tool - Simulated web search for the Manus Demo.

Returns mock search results by default. Can be extended to call a real
search API (e.g., SerpAPI, Tavily, DuckDuckGo) by replacing the
`_mock_search` method.
"""

from __future__ import annotations

import logging
from typing import Any

from tools.base import BaseTool

logger = logging.getLogger(__name__)

# Pre-defined mock results for common queries (educational demo)
MOCK_RESULTS: dict[str, list[dict[str, str]]] = {
    "default": [
        {
            "title": "Search Result 1",
            "snippet": "This is a simulated search result. In a production system, "
                       "this would be replaced by real web search API results.",
            "url": "https://example.com/result1",
        },
        {
            "title": "Search Result 2",
            "snippet": "Another simulated result providing additional context "
                       "for the agent to reason about.",
            "url": "https://example.com/result2",
        },
    ],
    "python": [
        {
            "title": "Python Official Documentation",
            "snippet": "Python is a high-level, interpreted programming language. "
                       "It supports multiple programming paradigms including procedural, "
                       "object-oriented, and functional programming.",
            "url": "https://docs.python.org",
        },
        {
            "title": "Python Tutorial - W3Schools",
            "snippet": "Python can be used for web development, data analysis, "
                       "artificial intelligence, scientific computing, and more.",
            "url": "https://www.w3schools.com/python/",
        },
    ],
}


class WebSearchTool(BaseTool):
    """Simulated web search tool that returns mock results."""

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return (
            "Search the web for information on a given query. "
            "Returns a list of relevant search results with titles and snippets."
        )

    @property
    def parameters_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query string",
                },
            },
            "required": ["query"],
        }

    async def execute(self, **kwargs: Any) -> str:
        query = kwargs.get("query", "")
        logger.info("Web search: '%s'", query)

        results = self._mock_search(query)

        # Format results as readable text
        lines = [f"Search results for: '{query}'\n"]
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. {r['title']}")
            lines.append(f"   {r['snippet']}")
            lines.append(f"   URL: {r['url']}\n")
        return "\n".join(lines)

    @staticmethod
    def _mock_search(query: str) -> list[dict[str, str]]:
        """Return mock results. Override this for real search integration."""
        query_lower = query.lower()
        for keyword, results in MOCK_RESULTS.items():
            if keyword in query_lower:
                return results
        return MOCK_RESULTS["default"]
