"""
Base Tool - Abstract interface for all tools in the Manus Demo.

Each tool exposes:
  - name / description for the LLM to understand its purpose
  - parameters_schema (JSON Schema) for OpenAI function-calling
  - execute() to actually run the tool
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class BaseTool(ABC):
    """Abstract base class for all agent tools."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique tool name used in function calls."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description of what the tool does."""

    @property
    @abstractmethod
    def parameters_schema(self) -> dict[str, Any]:
        """JSON Schema describing the tool's parameters."""

    @abstractmethod
    async def execute(self, **kwargs: Any) -> str:
        """Run the tool and return a string result."""

    # ------------------------------------------------------------------
    # OpenAI function-calling schema
    # ------------------------------------------------------------------

    def to_openai_tool(self) -> dict[str, Any]:
        """
        Convert to the OpenAI tools format:
        {
            "type": "function",
            "function": {
                "name": "...",
                "description": "...",
                "parameters": { ... JSON Schema ... }
            }
        }
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters_schema,
            },
        }
