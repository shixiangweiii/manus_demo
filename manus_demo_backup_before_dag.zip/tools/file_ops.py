"""
File Operations Tool - Read, write, and list files in a sandboxed directory.

Provides basic file I/O capabilities within a configured sandbox directory,
preventing access to files outside the sandbox for safety.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import config
from tools.base import BaseTool

logger = logging.getLogger(__name__)


class FileOpsTool(BaseTool):
    """File operations restricted to a sandbox directory."""

    def __init__(self):
        self._sandbox = config.SANDBOX_DIR
        os.makedirs(self._sandbox, exist_ok=True)

    @property
    def name(self) -> str:
        return "file_ops"

    @property
    def description(self) -> str:
        return (
            "Perform file operations: read, write, or list files. "
            "All operations are restricted to the sandbox directory. "
            "Use action='read' with filename to read, action='write' with "
            "filename and content to write, action='list' to list files."
        )

    @property
    def parameters_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["read", "write", "list"],
                    "description": "The file operation to perform",
                },
                "filename": {
                    "type": "string",
                    "description": "Name of the file (for read/write operations)",
                },
                "content": {
                    "type": "string",
                    "description": "Content to write (for write operation)",
                },
            },
            "required": ["action"],
        }

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        filename = kwargs.get("filename", "")
        content = kwargs.get("content", "")

        if action == "list":
            return self._list_files()
        elif action == "read":
            return self._read_file(filename)
        elif action == "write":
            return self._write_file(filename, content)
        else:
            return f"Error: Unknown action '{action}'. Use 'read', 'write', or 'list'."

    def _safe_path(self, filename: str) -> str | None:
        """Resolve filename within sandbox; return None if it escapes."""
        path = os.path.realpath(os.path.join(self._sandbox, filename))
        if not path.startswith(os.path.realpath(self._sandbox)):
            return None
        return path

    def _list_files(self) -> str:
        try:
            files = os.listdir(self._sandbox)
            if not files:
                return f"Sandbox directory is empty: {self._sandbox}"
            return f"Files in sandbox:\n" + "\n".join(f"  - {f}" for f in sorted(files))
        except Exception as exc:
            return f"Error listing files: {exc}"

    def _read_file(self, filename: str) -> str:
        if not filename:
            return "Error: filename is required for read operation."
        path = self._safe_path(filename)
        if path is None:
            return "Error: Access denied - path outside sandbox."
        if not os.path.exists(path):
            return f"Error: File not found: {filename}"
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f"Content of {filename}:\n{f.read()}"
        except Exception as exc:
            return f"Error reading file: {exc}"

    def _write_file(self, filename: str, content: str) -> str:
        if not filename:
            return "Error: filename is required for write operation."
        path = self._safe_path(filename)
        if path is None:
            return "Error: Access denied - path outside sandbox."
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) != self._sandbox else None
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            return f"Successfully wrote {len(content)} characters to {filename}"
        except Exception as exc:
            return f"Error writing file: {exc}"
