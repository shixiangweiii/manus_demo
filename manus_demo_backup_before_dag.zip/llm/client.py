"""
LLM Client - Unified wrapper for OpenAI-compatible APIs.
Supports any provider that exposes an OpenAI-compatible chat completions endpoint
(e.g., DeepSeek, Qwen/DashScope, Ollama, vLLM, etc.).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from openai import AsyncOpenAI

import config

logger = logging.getLogger(__name__)


class LLMClient:
    """Thin async wrapper around an OpenAI-compatible chat completions API."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
    ):
        self.model = model or config.LLM_MODEL
        self._client = AsyncOpenAI(
            base_url=base_url or config.LLM_BASE_URL,
            api_key=api_key or config.LLM_API_KEY,
        )

    # ------------------------------------------------------------------
    # Core chat completion
    # ------------------------------------------------------------------

    async def chat(
        self,
        messages: list[dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> str:
        """Simple chat completion that returns the assistant's text."""
        resp = await self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )
        return resp.choices[0].message.content or ""

    # ------------------------------------------------------------------
    # Chat with function-calling / tools
    # ------------------------------------------------------------------

    async def chat_with_tools(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> Any:
        """
        Chat completion with OpenAI-style function calling.
        Returns the raw response message object so the caller can inspect
        tool_calls and content.
        """
        resp = await self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )
        return resp.choices[0].message

    # ------------------------------------------------------------------
    # Convenience: structured JSON output
    # ------------------------------------------------------------------

    async def chat_json(
        self,
        messages: list[dict[str, Any]],
        temperature: float = 0.3,
        max_tokens: int = 4096,
        **kwargs: Any,
    ) -> Any:
        """
        Request a JSON response from the LLM.
        Falls back to extracting JSON from text if response_format is not supported.
        """
        try:
            resp = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                response_format={"type": "json_object"},
                **kwargs,
            )
            text = resp.choices[0].message.content or "{}"
        except Exception:
            logger.warning("JSON mode not supported, falling back to plain text")
            text = await self.chat(messages, temperature=temperature, max_tokens=max_tokens)

        return self._parse_json(text)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_json(text: str) -> Any:
        """Best-effort JSON extraction from LLM output."""
        text = text.strip()
        # Try direct parse first
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        # Try to find JSON block in markdown fences
        for fence in ("```json", "```"):
            if fence in text:
                start = text.index(fence) + len(fence)
                end = text.index("```", start)
                return json.loads(text[start:end].strip())
        raise ValueError(f"Could not parse JSON from LLM output:\n{text[:300]}")
