"""
Context Manager - Token-aware context window management with LLM-based compression.

Monitors the total token usage of conversation messages and automatically
compresses older messages into a concise summary when the context exceeds
the configured limit, preserving the system prompt and recent messages.
"""

from __future__ import annotations

import logging
from typing import Any

import config

logger = logging.getLogger(__name__)


class ContextManager:
    """
    Manages conversation context to stay within token limits.

    Strategy:
      1. Estimate token count for all messages.
      2. If over the limit, split into [system_prompt, old_messages, recent_messages].
      3. Summarize old_messages using the LLM.
      4. Replace old messages with a single summary message.
    """

    def __init__(
        self,
        max_tokens: int | None = None,
        reserve_recent: int = 6,
    ):
        self.max_tokens = max_tokens or config.MAX_CONTEXT_TOKENS
        self.reserve_recent = reserve_recent

    # ------------------------------------------------------------------
    # Token estimation
    # ------------------------------------------------------------------

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """
        Rough token estimation: ~1 token per 3 characters for English,
        ~1 token per 2 characters for CJK-heavy text.
        Avoids the need for tiktoken dependency.
        """
        return max(1, len(text) // 3)

    def estimate_messages_tokens(self, messages: list[dict[str, Any]]) -> int:
        """Estimate total tokens for a list of messages."""
        total = 0
        for msg in messages:
            content = msg.get("content", "") or ""
            total += self.estimate_tokens(content) + 4  # overhead per message
        return total

    # ------------------------------------------------------------------
    # Context compression
    # ------------------------------------------------------------------

    async def compress_if_needed(
        self,
        messages: list[dict[str, Any]],
        llm_client: Any,
    ) -> list[dict[str, Any]]:
        """
        Check if messages exceed token limit; if so, compress older messages
        via LLM summarization while keeping the system prompt and recent messages.

        Returns a (possibly shorter) list of messages.
        """
        total = self.estimate_messages_tokens(messages)
        if total <= self.max_tokens:
            return messages

        logger.info(
            "Context too long (~%d tokens, limit %d). Compressing...",
            total, self.max_tokens,
        )

        # Separate system prompt from conversation
        system_msgs = [m for m in messages if m.get("role") == "system"]
        non_system = [m for m in messages if m.get("role") != "system"]

        # Keep the most recent messages as-is
        if len(non_system) <= self.reserve_recent:
            return messages  # nothing to compress

        old_msgs = non_system[:-self.reserve_recent]
        recent_msgs = non_system[-self.reserve_recent:]

        # Build text to summarize
        old_text = self._messages_to_text(old_msgs)

        summary = await self._summarize(old_text, llm_client)

        # Construct compressed context
        summary_message = {
            "role": "system",
            "content": (
                f"[Context Summary - The following is a compressed summary of "
                f"earlier conversation]\n{summary}"
            ),
        }

        compressed = system_msgs + [summary_message] + recent_msgs
        new_total = self.estimate_messages_tokens(compressed)
        logger.info("Compressed context: %d tokens -> ~%d tokens", total, new_total)
        return compressed

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _messages_to_text(messages: list[dict[str, Any]]) -> str:
        """Convert messages to a readable text block for summarization."""
        lines = []
        for msg in messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "") or ""
            lines.append(f"[{role}]: {content}")
        return "\n".join(lines)

    @staticmethod
    async def _summarize(text: str, llm_client: Any) -> str:
        """Use the LLM to produce a concise summary of conversation history."""
        summary_prompt = [
            {
                "role": "system",
                "content": (
                    "You are a summarization assistant. Condense the following "
                    "conversation history into a brief, information-dense summary. "
                    "Preserve key facts, decisions, tool results, and action items. "
                    "Be concise but thorough."
                ),
            },
            {
                "role": "user",
                "content": f"Summarize this conversation:\n\n{text}",
            },
        ]
        try:
            summary = await llm_client.chat(summary_prompt, temperature=0.2, max_tokens=1024)
            return summary
        except Exception as exc:
            logger.error("Summarization failed: %s", exc)
            # Fallback: truncate to last N characters
            return text[-2000:] + "\n[... earlier context truncated ...]"
