"""
Configuration module for the Manus Demo.
Loads settings from environment variables or .env file.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# --- LLM API Configuration ---
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.deepseek.com/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "sk-55470978f1044b70955df04ab6908c02")
LLM_MODEL = os.getenv("LLM_MODEL", "deepseek-chat")

# --- Agent Limits ---
MAX_CONTEXT_TOKENS = int(os.getenv("MAX_CONTEXT_TOKENS", "8000"))
MAX_REACT_ITERATIONS = int(os.getenv("MAX_REACT_ITERATIONS", "10"))
MAX_REPLAN_ATTEMPTS = int(os.getenv("MAX_REPLAN_ATTEMPTS", "3"))

# --- Memory ---
MEMORY_DIR = os.path.expanduser(os.getenv("MEMORY_DIR", "~/.manus_demo"))
SHORT_TERM_WINDOW = int(os.getenv("SHORT_TERM_WINDOW", "20"))

# --- Knowledge ---
KNOWLEDGE_DOCS_DIR = os.path.join(os.path.dirname(__file__), "knowledge", "docs")
KNOWLEDGE_CHUNK_SIZE = int(os.getenv("KNOWLEDGE_CHUNK_SIZE", "500"))
KNOWLEDGE_TOP_K = int(os.getenv("KNOWLEDGE_TOP_K", "3"))

# --- Tools ---
SANDBOX_DIR = os.path.expanduser(os.getenv("SANDBOX_DIR", "~/.manus_demo/sandbox"))
CODE_EXEC_TIMEOUT = int(os.getenv("CODE_EXEC_TIMEOUT", "30"))
