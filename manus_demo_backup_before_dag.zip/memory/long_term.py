"""
Long-Term Memory - Persistent JSON-file storage for task summaries and learnings.

Stores completed task summaries so the agent can recall past experiences
and avoid repeating mistakes. Uses simple keyword matching for retrieval.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

import config
from schema import MemoryEntry

logger = logging.getLogger(__name__)


class LongTermMemory:
    """JSON-file backed persistent memory with keyword-based retrieval."""

    def __init__(self, memory_dir: str | None = None):
        self._dir = memory_dir or config.MEMORY_DIR
        os.makedirs(self._dir, exist_ok=True)
        self._file = os.path.join(self._dir, "memory.json")
        self._entries: list[MemoryEntry] = self._load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> list[MemoryEntry]:
        """Load entries from disk."""
        if not os.path.exists(self._file):
            return []
        try:
            with open(self._file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return [MemoryEntry(**e) for e in data]
        except Exception as exc:
            logger.warning("Failed to load long-term memory: %s", exc)
            return []

    def _save(self) -> None:
        """Persist entries to disk."""
        with open(self._file, "w", encoding="utf-8") as f:
            json.dump([e.model_dump() for e in self._entries], f, indent=2, ensure_ascii=False)

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    def store(self, entry: MemoryEntry) -> None:
        """Add a new memory entry and persist."""
        self._entries.append(entry)
        self._save()
        logger.info("Stored long-term memory: %s", entry.task[:60])

    def search(self, query: str, top_k: int = 3) -> list[MemoryEntry]:
        """
        Retrieve the most relevant memories using keyword overlap scoring.
        Simple but effective for a demo: counts how many query words appear
        in each entry's task + summary + learnings.
        """
        query_words = set(query.lower().split())
        scored: list[tuple[float, MemoryEntry]] = []

        for entry in self._entries:
            text = f"{entry.task} {entry.summary} {' '.join(entry.learnings)}".lower()
            entry_words = set(text.split())
            overlap = len(query_words & entry_words)
            if overlap > 0:
                scored.append((overlap, entry))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:top_k]]

    def get_all(self) -> list[MemoryEntry]:
        """Return all stored entries."""
        return list(self._entries)

    def clear(self) -> None:
        """Remove all entries."""
        self._entries.clear()
        self._save()

    # ------------------------------------------------------------------
    # Formatting
    # ------------------------------------------------------------------

    def format_memories(self, entries: list[MemoryEntry]) -> str:
        """Format memory entries into a readable context string."""
        if not entries:
            return "No relevant past experiences found."
        parts = []
        for i, e in enumerate(entries, 1):
            learnings = "; ".join(e.learnings) if e.learnings else "None"
            parts.append(
                f"[Memory {i}] Task: {e.task}\n"
                f"  Summary: {e.summary}\n"
                f"  Learnings: {learnings}"
            )
        return "\n".join(parts)

    def __len__(self) -> int:
        return len(self._entries)
