"""
Short-Term Memory - Sliding window buffer for recent conversation messages.

Keeps the most recent N messages in memory to provide immediate context
to agents without exceeding token limits.
"""

from __future__ import annotations

import logging
from typing import Any

import config

logger = logging.getLogger(__name__)


class ShortTermMemory:
    """In-memory sliding window that retains the last `window_size` messages."""

    def __init__(self, window_size: int | None = None):
        self.window_size = window_size or config.SHORT_TERM_WINDOW
        self._messages: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    def add(self, message: dict[str, Any]) -> None:
        """Append a message and evict the oldest if over the window size."""
        self._messages.append(message)
        if len(self._messages) > self.window_size:
            evicted = len(self._messages) - self.window_size
            self._messages = self._messages[evicted:]
            logger.debug("Short-term memory evicted %d old messages", evicted)

    def get_messages(self) -> list[dict[str, Any]]:
        """Return all messages currently in the window."""
        return list(self._messages)

    def get_recent(self, n: int = 5) -> list[dict[str, Any]]:
        """Return the most recent n messages."""
        return list(self._messages[-n:])

    def clear(self) -> None:
        """Clear all stored messages."""
        self._messages.clear()
        logger.debug("Short-term memory cleared")

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def to_text(self) -> str:
        """Serialize all messages into a readable text block."""
        lines = []
        for msg in self._messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            lines.append(f"[{role}]: {content}")
        return "\n".join(lines)

    def __len__(self) -> int:
        return len(self._messages)

    def __repr__(self) -> str:
        return f"ShortTermMemory(size={len(self._messages)}, window={self.window_size})"
