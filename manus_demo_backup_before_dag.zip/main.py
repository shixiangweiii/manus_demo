"""
Manus Demo - Interactive CLI entry point.

Launches the multi-agent pipeline with a rich console UI that displays
each phase of execution: planning, ReAct tool calls, reflection, etc.
"""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import Any

from rich.console import Console
from rich.logging import RichHandler
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from agents.orchestrator import OrchestratorAgent
from llm.client import LLMClient
from schema import Plan, Reflection, Step, StepResult
from tools.code_executor import CodeExecutorTool
from tools.file_ops import FileOpsTool
from tools.web_search import WebSearchTool

console = Console()

# ======================================================================
# UI Event Handler - Pretty-prints pipeline events
# ======================================================================

def on_event(event: str, data: Any) -> None:
    """Handle events from the orchestrator and display them in the console."""

    if event == "task_start":
        console.print()
        console.print(Panel(
            f"[bold]{data['task']}[/bold]",
            title="[bold blue]New Task[/bold blue]",
            border_style="blue",
        ))

    elif event == "phase":
        console.print(f"\n[bold cyan]>>> {data}[/bold cyan]")

    elif event == "memory":
        if "No relevant" not in str(data):
            console.print(Panel(str(data), title="[yellow]Long-term Memory[/yellow]", border_style="yellow"))

    elif event == "knowledge":
        if "No relevant" not in str(data):
            console.print(Panel(str(data), title="[green]Knowledge Retrieved[/green]", border_style="green"))

    elif event == "plan":
        plan: Plan = data
        table = Table(title="Execution Plan", show_header=True, header_style="bold magenta")
        table.add_column("Step", style="cyan", width=6)
        table.add_column("Description", style="white")
        table.add_column("Deps", style="dim", width=8)
        table.add_column("Status", width=10)
        for step in plan.steps:
            status_style = {
                "pending": "dim",
                "running": "yellow",
                "completed": "green",
                "failed": "red",
            }.get(step.status.value, "white")
            table.add_row(
                str(step.id),
                step.description,
                ", ".join(str(d) for d in step.dependencies) or "-",
                f"[{status_style}]{step.status.value}[/{status_style}]",
            )
        console.print(table)

    elif event == "step_start":
        step: Step = data["step"]
        console.print(f"\n  [bold yellow]>> Step {step.id}:[/bold yellow] {step.description}")

    elif event == "step_complete":
        result: StepResult = data["result"]
        output_preview = result.output[:500]
        console.print(f"  [green]   Step {result.step_id} completed.[/green]")
        if result.tool_calls_log:
            for tc in result.tool_calls_log:
                console.print(f"    [dim]Tool: {tc.tool_name}({tc.parameters})[/dim]")
                console.print(f"    [dim]  -> {tc.result[:200]}[/dim]")
        console.print(Panel(output_preview, title=f"Step {result.step_id} Output", border_style="green"))

    elif event == "step_failed":
        result: StepResult = data["result"]
        console.print(f"  [red]   Step {result.step_id} FAILED.[/red]")
        console.print(Panel(result.output[:500], title=f"Step {result.step_id} Error", border_style="red"))

    elif event == "reflection":
        ref: Reflection = data
        style = "green" if ref.passed else "red"
        verdict = "PASSED" if ref.passed else "NEEDS REWORK"
        console.print(Panel(
            f"Verdict: [{style}]{verdict}[/{style}]  |  Score: {ref.score:.2f}\n\n"
            f"{ref.feedback}\n\n"
            + (f"Suggestions:\n" + "\n".join(f"  - {s}" for s in ref.suggestions) if ref.suggestions else ""),
            title="[bold]Reflection[/bold]",
            border_style=style,
        ))

    elif event == "memory_stored":
        console.print("[dim]   (Result stored in long-term memory)[/dim]")

    elif event == "task_complete":
        console.print(Panel(
            data["answer"][:2000],
            title="[bold green]Final Answer[/bold green]",
            border_style="green",
        ))


# ======================================================================
# Main
# ======================================================================

def setup_logging(verbose: bool = False) -> None:
    """Configure logging with rich handler."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, show_path=False, rich_tracebacks=True)],
    )
    # Quiet noisy libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


async def run_interactive() -> None:
    """Interactive multi-turn conversation loop."""
    console.print(Panel(
        "[bold]Manus Demo[/bold] - Simplified Multi-Agent System\n\n"
        "This demo implements:\n"
        "  [cyan]1.[/cyan] Plan-and-Execute task decomposition\n"
        "  [cyan]2.[/cyan] ReAct (Reasoning + Acting) execution loop\n"
        "  [cyan]3.[/cyan] Result reflection and self-correction\n"
        "  [cyan]4.[/cyan] Short-term & long-term memory\n"
        "  [cyan]5.[/cyan] Context compression\n"
        "  [cyan]6.[/cyan] Knowledge retrieval\n\n"
        "Type your task and press Enter. Type [bold]quit[/bold] to exit.",
        title="[bold blue]Welcome[/bold blue]",
        border_style="blue",
    ))

    # Initialize components
    llm_client = LLMClient()
    tools = [WebSearchTool(), CodeExecutorTool(), FileOpsTool()]
    orchestrator = OrchestratorAgent(
        llm_client=llm_client,
        tools=tools,
        on_event=on_event,
    )

    while True:
        console.print()
        try:
            user_input = console.input("[bold blue]You > [/bold blue]").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            console.print("[dim]Goodbye![/dim]")
            break

        try:
            answer = await orchestrator.run(user_input)
        except KeyboardInterrupt:
            console.print("\n[yellow]Task interrupted.[/yellow]")
        except Exception as exc:
            console.print(f"\n[red]Error: {exc}[/red]")
            logging.exception("Unhandled error")


async def run_single(task: str) -> None:
    """Run a single task (non-interactive mode)."""
    llm_client = LLMClient()
    # 优化点，单独的工具系统
    # 和自己想的一样，其实只要有网络搜索、代码执行、文件操这些工具后，其实就可以打造一个基本的“通用AI”
    tools = [WebSearchTool(), CodeExecutorTool(), FileOpsTool()]
    orchestrator = OrchestratorAgent(
        llm_client=llm_client,
        tools=tools,
        on_event=on_event,
    )
    await orchestrator.run(task)


def main() -> None:
    verbose = "--verbose" in sys.argv or "-v" in sys.argv
    setup_logging(verbose)

    # Check for single-task mode: python main.py "your task here"
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if args:
        task = " ".join(args)
        # 任务作为参数放在命令行，执行单任务模式
        # 例如：python main.py "查询今天天气" -v
        asyncio.run(run_single(task))
    else:
        asyncio.run(run_interactive())


if __name__ == "__main__":
    main()
