"""
Knowledge Retriever - Simple TF-IDF keyword-based retrieval over local documents.

Loads text/markdown files from the knowledge docs directory, splits them into
chunks, and provides keyword-based search to inject relevant context into
agent prompts. Pure Python implementation with no external ML dependencies.
"""

from __future__ import annotations

import logging
import math
import os
import re
from typing import Any

import config

logger = logging.getLogger(__name__)


class KnowledgeRetriever:
    """
    Lightweight knowledge retrieval using TF-IDF scoring.

    Documents are loaded from the configured docs directory, split into
    fixed-size chunks, and indexed using an inverted TF-IDF index.
    """

    def __init__(self, docs_dir: str | None = None, chunk_size: int | None = None):
        self.docs_dir = docs_dir or config.KNOWLEDGE_DOCS_DIR
        self.chunk_size = chunk_size or config.KNOWLEDGE_CHUNK_SIZE
        self.top_k = config.KNOWLEDGE_TOP_K

        self._chunks: list[dict[str, Any]] = []  # {text, source, index}
        self._idf: dict[str, float] = {}
        self._tf_idf: list[dict[str, float]] = []  # per-chunk TF-IDF vectors

        self._build_index()

    # ------------------------------------------------------------------
    # Index building
    # ------------------------------------------------------------------

    def _build_index(self) -> None:
        """Load documents, chunk them, and compute TF-IDF."""
        if not os.path.isdir(self.docs_dir):
            logger.warning("Knowledge docs dir not found: %s", self.docs_dir)
            return

        # Load and chunk documents
        for filename in sorted(os.listdir(self.docs_dir)):
            if not filename.endswith((".txt", ".md")):
                continue
            filepath = os.path.join(self.docs_dir, filename)
            with open(filepath, "r", encoding="utf-8") as f:
                text = f.read()
            chunks = self._split_text(text, self.chunk_size)
            for i, chunk in enumerate(chunks):
                self._chunks.append({
                    "text": chunk,
                    "source": filename,
                    "index": i,
                })

        if not self._chunks:
            logger.info("No knowledge documents found in %s", self.docs_dir)
            return

        # Compute IDF
        n_docs = len(self._chunks)
        doc_freq: dict[str, int] = {}
        for chunk in self._chunks:
            words = set(self._tokenize(chunk["text"]))
            for w in words:
                doc_freq[w] = doc_freq.get(w, 0) + 1

        self._idf = {
            w: math.log((n_docs + 1) / (df + 1)) + 1
            for w, df in doc_freq.items()
        }

        # Compute TF-IDF vectors for each chunk
        for chunk in self._chunks:
            tf = self._compute_tf(chunk["text"])
            tfidf = {w: freq * self._idf.get(w, 1.0) for w, freq in tf.items()}
            self._tf_idf.append(tfidf)

        logger.info(
            "Knowledge index built: %d chunks from %d files",
            len(self._chunks),
            len(set(c["source"] for c in self._chunks)),
        )

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int | None = None) -> list[dict[str, Any]]:
        """
        Retrieve the top-K most relevant chunks for a query.

        Returns a list of dicts: {text, source, score}.
        """
        if not self._chunks:
            return []

        top_k = top_k or self.top_k
        query_tf = self._compute_tf(query)
        query_vec = {w: freq * self._idf.get(w, 1.0) for w, freq in query_tf.items()}

        scores: list[tuple[float, int]] = []
        for idx, chunk_vec in enumerate(self._tf_idf):
            score = self._cosine_similarity(query_vec, chunk_vec)
            if score > 0:
                scores.append((score, idx))

        scores.sort(key=lambda x: x[0], reverse=True)

        results = []
        for score, idx in scores[:top_k]:
            results.append({
                "text": self._chunks[idx]["text"],
                "source": self._chunks[idx]["source"],
                "score": round(score, 4),
            })
        return results

    def format_results(self, results: list[dict[str, Any]]) -> str:
        """Format search results into a context string for the LLM."""
        if not results:
            return "No relevant knowledge found."
        parts = []
        for i, r in enumerate(results, 1):
            parts.append(
                f"[Knowledge {i}] (source: {r['source']}, relevance: {r['score']})\n"
                f"{r['text']}"
            )
        return "\n\n".join(parts)

    # ------------------------------------------------------------------
    # Text processing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        """Simple word tokenization: lowercase, alphanumeric only."""
        return re.findall(r"[a-z0-9]+", text.lower())

    @staticmethod
    def _compute_tf(text: str) -> dict[str, float]:
        """Compute term frequency (normalized)."""
        words = re.findall(r"[a-z0-9]+", text.lower())
        if not words:
            return {}
        freq: dict[str, int] = {}
        for w in words:
            freq[w] = freq.get(w, 0) + 1
        max_freq = max(freq.values())
        return {w: c / max_freq for w, c in freq.items()}

    @staticmethod
    def _cosine_similarity(a: dict[str, float], b: dict[str, float]) -> float:
        """Cosine similarity between two sparse vectors."""
        common = set(a.keys()) & set(b.keys())
        if not common:
            return 0.0
        dot = sum(a[k] * b[k] for k in common)
        norm_a = math.sqrt(sum(v * v for v in a.values()))
        norm_b = math.sqrt(sum(v * v for v in b.values()))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)

    @staticmethod
    def _split_text(text: str, chunk_size: int) -> list[str]:
        """Split text into chunks at paragraph boundaries."""
        paragraphs = re.split(r"\n\s*\n", text.strip())
        chunks: list[str] = []
        current = ""
        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            if len(current) + len(para) + 1 > chunk_size and current:
                chunks.append(current.strip())
                current = para
            else:
                current = f"{current}\n{para}" if current else para
        if current.strip():
            chunks.append(current.strip())
        return chunks if chunks else [text.strip()] if text.strip() else []
