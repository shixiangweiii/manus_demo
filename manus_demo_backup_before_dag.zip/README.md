# Manus Demo - Simplified Multi-Agent System

A minimal, educational implementation of a Manus-style multi-agent AI system. Built to
help you understand the core principles behind autonomous AI agents: task planning,
tool-augmented execution, self-reflection, memory, and context management.

## Architecture

```
User Task
   │
   ▼
┌─────────────────────────────────┐
│       Orchestrator Agent        │  ← Coordinates the full pipeline
│  ┌───────────┐  ┌───────────┐  │
│  │  Memory   │  │ Knowledge │  │  ← Retrieves past experience & docs
│  │ (ST + LT) │  │ Retriever │  │
│  └───────────┘  └───────────┘  │
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│        Planner Agent            │  ← Plan-and-Execute pattern
│  Decomposes task → [Steps]      │     LLM creates structured plan
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│        Executor Agent           │  ← ReAct pattern
│  For each step:                 │     Thought → Action → Observation
│    Thought → Tool Call →        │     Uses: web_search, execute_python,
│    Observation → Repeat         │           file_ops
└──────────┬──────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│       Reflector Agent           │  ← Quality gate
│  Validates results              │     May trigger re-planning
│  Score + Feedback               │
└──────────┬──────────────────────┘
           │
           ▼
       Final Answer
```

## Key Design Patterns

### 1. Plan-and-Execute
The **Planner Agent** decomposes a high-level task into ordered, actionable steps before
any execution begins. If execution fails, it can dynamically re-plan with feedback.

### 2. ReAct (Reasoning + Acting)
The **Executor Agent** follows the ReAct loop for each step:
- **Thought**: LLM reasons about the current situation
- **Action**: LLM selects and calls a tool via function calling
- **Observation**: Tool result is fed back to the LLM
- Repeat until the step objective is achieved

### 3. Reflection & Self-Correction
The **Reflector Agent** evaluates execution quality and can trigger re-planning,
creating a self-improving feedback loop.

## Project Structure

```
├── main.py                    # Interactive CLI entry point
├── config.py                  # Configuration (API keys, limits)
├── schema.py                  # Pydantic data models
├── agents/
│   ├── base.py               # BaseAgent (LLM calls, message history)
│   ├── orchestrator.py       # Orchestrator (pipeline coordinator)
│   ├── planner.py            # Planner (Plan-and-Execute)
│   ├── executor.py           # Executor (ReAct loop)
│   └── reflector.py          # Reflector (result validation)
├── memory/
│   ├── short_term.py         # Sliding window message buffer
│   └── long_term.py          # JSON-file persistent memory
├── context/
│   └── manager.py            # Token estimation + LLM summarization
├── knowledge/
│   ├── retriever.py          # TF-IDF keyword-based retrieval
│   └── docs/                 # Knowledge base documents
├── tools/
│   ├── base.py               # BaseTool interface
│   ├── web_search.py         # Mock web search
│   ├── code_executor.py      # Python subprocess execution
│   └── file_ops.py           # Sandboxed file operations
└── llm/
    └── client.py             # OpenAI-compatible API wrapper
```

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure LLM API

Copy the example config and fill in your API credentials:

```bash
cp .env.example .env
```

Edit `.env` with your settings:

```env
# DeepSeek
LLM_BASE_URL=https://api.deepseek.com/v1
LLM_API_KEY=sk-your-key-here
LLM_MODEL=deepseek-chat

# Or Ollama (local)
# LLM_BASE_URL=http://localhost:11434/v1
# LLM_API_KEY=ollama
# LLM_MODEL=llama3
```

### 3. Run

**Interactive mode:**
```bash
python main.py
```

**Single task mode:**
```bash
python main.py "Calculate the first 10 Fibonacci numbers and save them to a file"
```

**Verbose mode (debug logging):**
```bash
python main.py -v
```

## Core Concepts Explained

### Multi-Agent Architecture
Instead of a single monolithic agent, the system uses specialized agents that each
handle one aspect of the task lifecycle. The Orchestrator coordinates their interactions.

### Context Compression
When conversation history grows too long, the `ContextManager` uses the LLM to
summarize older messages, preserving important information within token limits.

### Memory System
- **Short-term**: Sliding window of recent messages for immediate context
- **Long-term**: Persistent JSON storage of task summaries and learnings, enabling
  cross-session knowledge transfer

### Knowledge Retrieval
A lightweight TF-IDF retriever indexes local documents and injects relevant chunks
into agent prompts, providing domain-specific context without external vector databases.

### Tool System
Tools use OpenAI-compatible function calling schemas, allowing the LLM to naturally
select and invoke tools during the ReAct execution loop.

## Extending the Demo

### Add a New Tool
1. Create a new file in `tools/` inheriting from `BaseTool`
2. Implement `name`, `description`, `parameters_schema`, and `execute()`
3. Add it to the tools list in `main.py`

### Add Knowledge Documents
Place `.txt` or `.md` files in `knowledge/docs/` - they will be automatically
indexed on startup.

### Use a Different LLM
Update the `.env` file with any OpenAI-compatible API endpoint.
