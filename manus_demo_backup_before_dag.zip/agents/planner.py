"""
Planner Agent - Implements the Plan-and-Execute pattern.

Responsibilities:
  1. Decompose a high-level user task into a structured, ordered plan.
  2. Support dynamic re-planning when steps fail or circumstances change.

The planner prompts the LLM to output a JSON plan, which is parsed into
the Plan/Step Pydantic models.
"""

from __future__ import annotations

import logging
from typing import Any

from agents.base import BaseAgent
from context.manager import ContextManager
from llm.client import LLMClient
from schema import Plan, Step, StepResult, StepStatus

logger = logging.getLogger(__name__)

PLANNER_SYSTEM_PROMPT = """\
You are a task planning agent. Your job is to decompose a complex user task
into a clear, ordered sequence of executable steps.

Rules:
1. Break the task into 2-6 concrete, actionable steps.
2. Each step should be independently executable by an executor agent that
   has access to tools: web_search, execute_python, file_ops.
3. Order steps logically; specify dependencies if a step requires output
   from a prior step.
4. Keep step descriptions clear and specific.

You MUST respond with a valid JSON object in this exact format:
{
  "steps": [
    {
      "id": 1,
      "description": "What this step should accomplish",
      "dependencies": []
    },
    {
      "id": 2,
      "description": "Next step description",
      "dependencies": [1]
    }
  ]
}
"""


class PlannerAgent(BaseAgent):
    """
    Plan-and-Execute planner that creates and revises structured plans.

    Workflow:
      1. create_plan() -> LLM decomposes task into steps
      2. replan()      -> LLM adjusts plan based on execution feedback
    """

    def __init__(self, llm_client: LLMClient, context_manager: ContextManager | None = None):
        super().__init__(
            name="Planner",
            system_prompt=PLANNER_SYSTEM_PROMPT,
            llm_client=llm_client,
            context_manager=context_manager,
        )

    async def create_plan(self, task: str, context: str = "") -> Plan:
        """
        Create a structured plan for the given task.

        Args:
            task: The user's high-level task description.
            context: Additional context (knowledge, memory) to inform planning.

        Returns:
            A Plan object with ordered steps.
        """
        prompt = f"Create an execution plan for this task:\n\nTask: {task}"
        if context:
            prompt += f"\n\nRelevant context:\n{context}"

        logger.info("[Planner] Creating plan for: %s", task[:80])
        # 任务task -> 结构化json
        result = await self.think_json(prompt, temperature=0.3)
        # 解析任务
        # task:string -> 结构化对象 Plan
        return self._parse_plan(task, result)

    async def replan(
        self,
        task: str,
        completed_results: list[StepResult],
        failed_step: Step | None = None,
        feedback: str = "",
    ) -> Plan:
        """
        Revise the plan based on execution progress and feedback.

        Args:
            task: Original task.
            completed_results: Results from steps completed so far.
            failed_step: The step that failed (if any).
            feedback: Reflector feedback or error details.

        Returns:
            A revised Plan.
        """
        completed_summary = "\n".join(
            f"- Step {r.step_id}: {'SUCCESS' if r.success else 'FAILED'} - {r.output[:200]}"
            for r in completed_results
        )

        prompt = (
            f"The original task needs re-planning.\n\n"
            f"Task: {task}\n\n"
            f"Completed steps so far:\n{completed_summary}\n"
        )
        if failed_step:
            prompt += f"\nFailed step: {failed_step.description}\n"
        if feedback:
            prompt += f"\nFeedback: {feedback}\n"

        prompt += (
            "\nCreate a NEW plan for the REMAINING work. "
            "Do not repeat already-completed steps. "
            "Account for the feedback and any failures."
        )

        logger.info("[Planner] Re-planning task: %s", task[:80])

        result = await self.think_json(prompt, temperature=0.3)
        return self._parse_plan(task, result)

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_plan(task: str, data: Any) -> Plan:
        """Parse LLM JSON output into a Plan model."""
        steps = []
        raw_steps = data.get("steps", []) if isinstance(data, dict) else []
        for s in raw_steps:
            steps.append(Step(
                id=s.get("id", len(steps) + 1),
                description=s.get("description", ""),
                dependencies=s.get("dependencies", []),
                status=StepStatus.PENDING,
            ))
        plan = Plan(task=task, steps=steps, current_step_index=0)
        logger.info("[Planner] Plan created with %d steps", len(steps))
        return plan
