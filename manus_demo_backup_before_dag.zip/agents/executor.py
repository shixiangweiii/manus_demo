"""
Executor Agent - Implements the ReAct (Reasoning + Acting) pattern.

For each plan step, the executor runs a loop:
  1. Thought  - LLM reasons about what to do next
  2. Action   - LLM selects a tool and provides parameters
  3. Observe  - Tool is executed, result is fed back to the LLM
  4. Repeat until the step objective is met or max iterations reached

Uses OpenAI-compatible function calling to let the LLM naturally select tools.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from agents.base import BaseAgent
from context.manager import ContextManager
from llm.client import LLMClient
from schema import Step, StepResult, ToolCallRecord
from tools.base import BaseTool

logger = logging.getLogger(__name__)

EXECUTOR_SYSTEM_PROMPT = """\
You are a task execution agent that follows the ReAct paradigm.

For each step you receive, you should:
1. THINK about what needs to be done and which tool to use.
2. ACT by calling the appropriate tool with correct parameters.
3. OBSERVE the tool's output.
4. REPEAT if needed, or provide a final answer.

When you have completed the step objective, respond with a clear summary of
what was accomplished. Do NOT call any more tools once the step is done.

Available tools will be provided via function calling. Use them wisely.
Be concise and focused on completing the step objective.
"""


class ExecutorAgent(BaseAgent):
    """
    ReAct executor that runs individual plan steps using tools.

    The core loop:
      while not done:
          response = LLM(messages, tools)
          if response has tool_calls:
              for each tool_call:
                  result = tool.execute(**args)
                  record observation
          else:
              step is done, return final answer
    """

    def __init__(
        self,
        llm_client: LLMClient,
        tools: list[BaseTool],
        max_iterations: int | None = None,
        context_manager: ContextManager | None = None,
    ):
        super().__init__(
            name="Executor",
            system_prompt=EXECUTOR_SYSTEM_PROMPT,
            llm_client=llm_client,
            context_manager=context_manager,
        )
        self.tools = {t.name: t for t in tools}
        self.tool_schemas = [t.to_openai_tool() for t in tools]
        self.max_iterations = max_iterations or __import__("config").MAX_REACT_ITERATIONS

    async def execute_step(self, step: Step, context: str = "") -> StepResult:
        """
        Execute a single plan step using the ReAct loop.

        Args:
            step: The plan step to execute.
            context: Additional context from prior steps or knowledge.

        Returns:
            StepResult with success status, output, and tool call log.
        """
        # Reset conversation for each step (keeps executor focused)
        self.reset()
        # 具体步骤再 NLU 转成结构化对象
        prompt = f"Execute the following step:\n\nStep {step.id}: {step.description}"
        if context:
            prompt += f"\n\nContext from previous steps:\n{context}"

        tool_calls_log: list[ToolCallRecord] = []
        iteration = 0

        logger.info("[Executor] Starting step %d: %s", step.id, step.description[:80])

        while iteration < self.max_iterations:
            iteration += 1
            logger.debug("[Executor] ReAct iteration %d/%d", iteration, self.max_iterations)

            try:
                # 把相关工具带入到步骤执行的 NLU 中
                response_msg = await self.think_with_tools(
                    prompt if iteration == 1 else "Continue executing the step based on the tool results above.",
                    tools=self.tool_schemas,
                    temperature=0.5,
                )
            except Exception as exc:
                logger.error("[Executor] LLM call failed: %s", exc)
                return StepResult(
                    step_id=step.id,
                    success=False,
                    output=f"LLM call failed: {exc}",
                    tool_calls_log=tool_calls_log,
                )

            # If no tool calls, the LLM is providing its final answer
            if not response_msg.tool_calls:
                final_output = response_msg.content or "Step completed (no output)."
                logger.info("[Executor] Step %d completed in %d iterations", step.id, iteration)
                return StepResult(
                    step_id=step.id,
                    success=True,
                    output=final_output,
                    tool_calls_log=tool_calls_log,
                )

            # Process each tool call
            for tool_call in response_msg.tool_calls:
                func_name = tool_call.function.name
                try:
                    func_args = json.loads(tool_call.function.arguments)
                except json.JSONDecodeError:
                    func_args = {}

                logger.info("[Executor] Tool call: %s(%s)", func_name, func_args)

                # Execute the tool
                tool = self.tools.get(func_name)
                if tool is None:
                    result = f"Error: Unknown tool '{func_name}'"
                else:
                    try:
                        # 工具执行
                        result = await tool.execute(**func_args)
                    except Exception as exc:
                        result = f"Tool execution error: {exc}"

                # Record the tool call
                tool_calls_log.append(ToolCallRecord(
                    tool_name=func_name,
                    parameters=func_args,
                    result=result[:1000],  # truncate for logging
                ))

                # Feed observation back to the LLM
                # 工具结果放入工具执行循环
                self.add_tool_result(tool_call.id, result)

        # Max iterations reached
        logger.warning("[Executor] Step %d hit max iterations (%d)", step.id, self.max_iterations)
        return StepResult(
            step_id=step.id,
            success=False,
            output=f"Step did not complete within {self.max_iterations} iterations.",
            tool_calls_log=tool_calls_log,
        )
