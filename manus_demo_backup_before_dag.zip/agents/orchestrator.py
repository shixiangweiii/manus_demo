"""
Orchestrator Agent - Central coordinator for the multi-agent pipeline.

The orchestrator manages the full lifecycle of a task:
  1. Retrieve relevant memories and knowledge
  2. Delegate to Planner for plan creation (Plan-and-Execute)
  3. Delegate to Executor for step execution (ReAct)
  4. Delegate to Reflector for result validation
  5. Handle re-planning if reflection fails
  6. Store learnings in long-term memory
"""

from __future__ import annotations

import logging
from typing import Any, Callable

import config
from agents.base import BaseAgent
from agents.executor import ExecutorAgent
from agents.planner import PlannerAgent
from agents.reflector import ReflectorAgent
from context.manager import ContextManager
from knowledge.retriever import KnowledgeRetriever
from llm.client import LLMClient
from memory.long_term import LongTermMemory
from memory.short_term import ShortTermMemory
from schema import MemoryEntry, Plan, StepResult, StepStatus
from tools.base import BaseTool

logger = logging.getLogger(__name__)


class OrchestratorAgent:
    """
    Top-level agent that orchestrates the Plan-Execute-Reflect pipeline.

    Architecture:
        User Task
           |
           v
        [Orchestrator] -- retrieves memory & knowledge
           |
           v
        [Planner]      -- Plan-and-Execute: creates structured plan
           |
           v
        [Executor]     -- ReAct loop: executes each step with tools
           |
           v
        [Reflector]    -- validates results, may trigger re-plan
           |
           v
        Final Answer   -- stored in long-term memory
    """

    def __init__(
        self,
        llm_client: LLMClient | None = None,
        tools: list[BaseTool] | None = None,
        on_event: Callable[[str, Any], None] | None = None,
    ):
        self.llm_client = llm_client or LLMClient()
        self.context_manager = ContextManager()

        # Sub-agents
        self.planner = PlannerAgent(self.llm_client, self.context_manager)
        self.executor = ExecutorAgent(
            self.llm_client,
            tools=tools or [],
            context_manager=self.context_manager,
        )
        self.reflector = ReflectorAgent(self.llm_client, self.context_manager)

        # Memory & knowledge
        self.short_term = ShortTermMemory()
        self.long_term = LongTermMemory()
        self.knowledge = KnowledgeRetriever()

        # Event callback for UI updates
        self._on_event = on_event or (lambda *_: None)

        self.max_replan = config.MAX_REPLAN_ATTEMPTS

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    async def run(self, task: str) -> str:
        """
        Execute a user task through the full multi-agent pipeline.

        Args:
            task: Natural language task description.

        Returns:
            Final answer/result as a string.
        """
        # 发射事件
        self._emit("task_start", {"task": task})

        # --- Phase 1: Gather context ---
        self._emit("phase", "Gathering context...")

        # Retrieve relevant long-term memories
        # 长期记忆中召回上下文
        memories = self.long_term.search(task)
        memory_context = self.long_term.format_memories(memories)
        self._emit("memory", memory_context)

        # Retrieve relevant knowledge
        # 知识库召回上下文
        knowledge_results = self.knowledge.search(task)
        knowledge_context = self.knowledge.format_results(knowledge_results)
        self._emit("knowledge", knowledge_context)

        # Record in short-term memory
        self.short_term.add({"role": "user", "content": task})

        combined_context = ""
        if memories:
            combined_context += f"=== Past Experience ===\n{memory_context}\n\n"
        if knowledge_results:
            combined_context += f"=== Relevant Knowledge ===\n{knowledge_context}\n\n"

        # --- Phase 2: Plan ---
        self._emit("phase", "Planning...")
        # 制定计划
        plan = await self.planner.create_plan(task, combined_context)
        # 发射事件
        self._emit("plan", plan)

        # --- Phase 3: Execute & Reflect (with re-planning loop) ---
        final_answer = await self._execute_and_reflect(task, plan, combined_context)

        # --- Phase 4: Store in memory ---
        # 记忆
        self._store_memory(task, final_answer)
        # 短期记忆
        self.short_term.add({"role": "assistant", "content": final_answer})
        # 任务完成
        self._emit("task_complete", {"answer": final_answer})
        return final_answer

    # ------------------------------------------------------------------
    # Execute-Reflect loop
    # ------------------------------------------------------------------

    async def _execute_and_reflect(
        self,
        task: str,
        plan: Plan,
        context: str,
    ) -> str:
        """Execute plan steps and reflect, with re-planning support."""
        all_results: list[StepResult] = []
        # 重试 max_replan 次
        for attempt in range(self.max_replan + 1):
            # Execute each step
            self._emit("phase", f"Executing plan (attempt {attempt + 1})...")
            step_context = context
            # 按照上一步NLU的得到的结构化plan对象处理
            for i, step in enumerate(plan.steps):
                if step.status == StepStatus.COMPLETED:
                    continue

                step.status = StepStatus.RUNNING
                plan.current_step_index = i
                self._emit("step_start", {"step": step, "index": i})

                # Build context from previous step results
                # 构造计划中的每一步的上下文
                if all_results:
                    prev_summary = "\n".join(
                        f"Step {r.step_id}: {r.output[:300]}"
                        for r in all_results
                    )
                    step_context = f"{context}\n\nPrevious results:\n{prev_summary}"

                # Execute with ReAct loop
                result = await self.executor.execute_step(step, step_context)
                all_results.append(result)

                if result.success:
                    step.status = StepStatus.COMPLETED
                    step.result = result.output
                    self._emit("step_complete", {"step": step, "result": result})
                else:
                    step.status = StepStatus.FAILED
                    self._emit("step_failed", {"step": step, "result": result})

            # Reflect on results
            self._emit("phase", "Reflecting on results...")
            reflection = await self.reflector.reflect(task, plan, all_results)
            self._emit("reflection", reflection)

            if reflection.passed:
                # Compile final answer from all results
                return self._compile_answer(task, all_results)

            # Re-plan if reflection failed and we have attempts left
            if attempt < self.max_replan:
                self._emit("phase", f"Re-planning based on feedback (attempt {attempt + 2})...")
                failed_steps = [
                    s for s in plan.steps if s.status == StepStatus.FAILED
                ]
                plan = await self.planner.replan(
                    task,
                    completed_results=[r for r in all_results if r.success],
                    failed_step=failed_steps[0] if failed_steps else None,
                    feedback=reflection.feedback,
                )
                self._emit("plan", plan)
                # Keep successful results, reset for new plan
                all_results = [r for r in all_results if r.success]
            else:
                logger.warning("Max re-plan attempts reached. Returning best effort.")
                return self._compile_answer(task, all_results)

        return "Task could not be completed after maximum attempts."

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compile_answer(task: str, results: list[StepResult]) -> str:
        """Compile step results into a coherent final answer."""
        successful = [r for r in results if r.success]
        if not successful:
            return "Unfortunately, no steps completed successfully."

        parts = []
        for r in successful:
            parts.append(r.output)
        return "\n\n".join(parts)

    def _store_memory(self, task: str, answer: str) -> None:
        """Store task completion in long-term memory."""
        entry = MemoryEntry(
            task=task,
            summary=answer[:500],
            learnings=[f"Completed task: {task[:100]}"],
        )
        self.long_term.store(entry)
        self._emit("memory_stored", entry)

    def _emit(self, event: str, data: Any = None) -> None:
        """Emit an event to the UI callback."""
        try:
            self._on_event(event, data)
        except Exception:
            pass  # UI errors should never crash the pipeline
