"""
Base Agent - Foundation class for all agents in the Manus Demo.

Provides common functionality:
  - System prompt management
  - Message history tracking
  - LLM interaction via the shared LLM client
  - Integration with context manager for token-aware conversations
"""

from __future__ import annotations

import logging
from typing import Any

from context.manager import ContextManager
from llm.client import LLMClient

logger = logging.getLogger(__name__)


class BaseAgent:
    """
    Base class that all specialized agents inherit from.

    Each agent maintains its own message history and system prompt,
    and delegates LLM calls to the shared LLMClient instance.
    """

    def __init__(
        self,
        name: str,
        system_prompt: str,
        llm_client: LLMClient,
        context_manager: ContextManager | None = None,
    ):
        self.name = name
        self.system_prompt = system_prompt
        self.llm_client = llm_client
        self.context_manager = context_manager or ContextManager()
        self._messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt}
        ]

    # ------------------------------------------------------------------
    # Message management
    # ------------------------------------------------------------------

    def add_message(self, role: str, content: str) -> None:
        """Append a message to this agent's conversation history."""
        self._messages.append({"role": role, "content": content})

    def get_messages(self) -> list[dict[str, Any]]:
        """Return a copy of all messages."""
        return list(self._messages)

    def reset(self) -> None:
        """Clear conversation history, keeping only the system prompt."""
        self._messages = [{"role": "system", "content": self.system_prompt}]

    # ------------------------------------------------------------------
    # LLM interaction
    # ------------------------------------------------------------------

    async def think(self, user_input: str, **kwargs: Any) -> str:
        """
        Send user_input to the LLM with full conversation context.
        Handles context compression if messages are too long.
        """
        self.add_message("user", user_input)

        # Compress context if needed
        self._messages = await self.context_manager.compress_if_needed(
            self._messages, self.llm_client
        )

        response = await self.llm_client.chat(self._messages, **kwargs)
        self.add_message("assistant", response)
        logger.debug("[%s] Response: %s", self.name, response[:200])
        return response

    async def think_json(self, user_input: str, **kwargs: Any) -> Any:
        """Send user_input and expect a JSON response."""
        self.add_message("user", user_input)

        self._messages = await self.context_manager.compress_if_needed(
            self._messages, self.llm_client
        )

        result = await self.llm_client.chat_json(self._messages, **kwargs)
        self.add_message("assistant", str(result))
        return result

    async def think_with_tools(
        self,
        user_input: str,
        tools: list[dict[str, Any]],
        **kwargs: Any,
    ) -> Any:
        """
        Send user_input with tool definitions, returning the raw response
        message so the caller can handle tool_calls.
        """
        self.add_message("user", user_input)

        self._messages = await self.context_manager.compress_if_needed(
            self._messages, self.llm_client
        )

        response_msg = await self.llm_client.chat_with_tools(
            self._messages, tools, **kwargs
        )

        # Record the assistant response in history
        assistant_dict: dict[str, Any] = {
            "role": "assistant",
            "content": response_msg.content or "",
        }
        if response_msg.tool_calls:
            assistant_dict["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in response_msg.tool_calls
            ]
        self._messages.append(assistant_dict)

        return response_msg

    def add_tool_result(self, tool_call_id: str, result: str) -> None:
        """Record a tool execution result in the message history."""
        self._messages.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "content": result,
        })

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name!r}, messages={len(self._messages)})"
