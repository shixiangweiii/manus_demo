"""
Reflector Agent - Validates and reflects on task execution results.

After all plan steps have been executed, the reflector:
  1. Evaluates whether the task was truly completed.
  2. Assesses the quality of the output.
  3. Provides specific feedback and improvement suggestions.
  4. Decides if re-planning is needed.
"""

from __future__ import annotations

import logging
from typing import Any

from agents.base import BaseAgent
from context.manager import ContextManager
from llm.client import LLMClient
from schema import Plan, Reflection, StepResult

logger = logging.getLogger(__name__)

REFLECTOR_SYSTEM_PROMPT = """\
You are a reflection and verification agent. Your job is to evaluate the
quality and completeness of task execution results.

Given the original task, the execution plan, and the results of each step,
you must:

1. Assess whether the task objective was fully achieved.
2. Identify any gaps, errors, or areas for improvement.
3. Provide a quality score from 0.0 to 1.0.
4. Decide if re-planning is needed (passed=false) or if the result is acceptable (passed=true).

Respond with a valid JSON object in this exact format:
{
  "passed": true/false,
  "score": 0.0-1.0,
  "feedback": "Overall evaluation of the results",
  "suggestions": ["suggestion 1", "suggestion 2"]
}

Be fair but rigorous. Only set passed=false if there are significant issues.
"""


class ReflectorAgent(BaseAgent):
    """
    Validates execution results and provides quality feedback.

    The reflector acts as a quality gate: if the results are inadequate,
    it returns passed=false with specific feedback, triggering re-planning.
    """

    def __init__(self, llm_client: LLMClient, context_manager: ContextManager | None = None):
        super().__init__(
            name="Reflector",
            system_prompt=REFLECTOR_SYSTEM_PROMPT,
            llm_client=llm_client,
            context_manager=context_manager,
        )

    async def reflect(
        self,
        task: str,
        plan: Plan,
        results: list[StepResult],
    ) -> Reflection:
        """
        Evaluate the execution results against the original task.

        Args:
            task: The original user task.
            plan: The execution plan that was followed.
            results: Results from each executed step.

        Returns:
            A Reflection object with pass/fail verdict and feedback.
        """
        self.reset()  # fresh context for each reflection

        # Build the evaluation prompt
        steps_summary = "\n".join(
            f"  Step {s.id}: {s.description}" for s in plan.steps
        )
        results_summary = "\n".join(
            f"  Step {r.step_id} [{'OK' if r.success else 'FAIL'}]: {r.output[:300]}"
            for r in results
        )

        prompt = (
            f"Evaluate the following task execution:\n\n"
            f"TASK: {task}\n\n"
            f"PLAN:\n{steps_summary}\n\n"
            f"RESULTS:\n{results_summary}\n\n"
            f"Provide your evaluation as JSON."
        )

        logger.info("[Reflector] Evaluating results for: %s", task[:80])

        try:
            data = await self.think_json(prompt, temperature=0.2)
            reflection = Reflection(
                passed=data.get("passed", False),
                score=float(data.get("score", 0.5)),
                feedback=data.get("feedback", ""),
                suggestions=data.get("suggestions", []),
            )
        except Exception as exc:
            logger.error("[Reflector] Failed to parse reflection: %s", exc)
            # Default to passing to avoid infinite loops
            reflection = Reflection(
                passed=True,
                score=0.5,
                feedback=f"Reflection parsing failed: {exc}. Defaulting to pass.",
                suggestions=[],
            )

        logger.info(
            "[Reflector] Verdict: %s (score: %.2f)",
            "PASSED" if reflection.passed else "NEEDS REWORK",
            reflection.score,
        )
        return reflection
