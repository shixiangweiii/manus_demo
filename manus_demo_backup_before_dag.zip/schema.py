"""
Pydantic data models for the Manus Demo.
Defines the core data structures used across agents, memory, and tools.
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# --- Step & Plan (Plan-and-Execute) ---

class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Step(BaseModel):
    id: int = Field(description="Unique step identifier")
    description: str = Field(description="What this step should accomplish")
    dependencies: list[int] = Field(default_factory=list, description="IDs of prerequisite steps")
    status: StepStatus = StepStatus.PENDING
    result: str | None = None


class Plan(BaseModel):
    task: str = Field(description="The original user task")
    steps: list[Step] = Field(default_factory=list, description="Ordered list of steps")
    current_step_index: int = 0


# --- Execution Results ---

class ToolCallRecord(BaseModel):
    tool_name: str
    parameters: dict[str, Any] = Field(default_factory=dict)
    result: str = ""


class StepResult(BaseModel):
    step_id: int
    success: bool
    output: str = ""
    tool_calls_log: list[ToolCallRecord] = Field(default_factory=list)


# --- Reflection ---

class Reflection(BaseModel):
    passed: bool = Field(description="Whether the task is considered complete")
    score: float = Field(default=0.0, description="Quality score 0-1")
    feedback: str = Field(default="", description="Overall evaluation")
    suggestions: list[str] = Field(default_factory=list, description="Improvement suggestions")


# --- Memory ---

class MemoryEntry(BaseModel):
    task: str
    summary: str
    learnings: list[str] = Field(default_factory=list)
    timestamp: float = Field(default_factory=time.time)


# --- Message ---

class Message(BaseModel):
    role: str = Field(description="One of: system, user, assistant, tool")
    content: str = ""
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None
    name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to OpenAI-compatible message dict."""
        d: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls is not None:
            d["tool_calls"] = self.tool_calls
        if self.tool_call_id is not None:
            d["tool_call_id"] = self.tool_call_id
        if self.name is not None:
            d["name"] = self.name
        return d
